class Inverter():
    pass